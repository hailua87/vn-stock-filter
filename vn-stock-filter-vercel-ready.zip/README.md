# VN Stock Filter

Ứng dụng watchlist cá nhân cho cổ phiếu thường đang giao dịch trên HOSE, HNX và UPCoM. Hệ thống chuyển các nguyên tắc đầu tư tăng trưởng bền vững của Philip Fisher thành quy trình nghiên cứu có bằng chứng, có kiểm soát chất lượng dữ liệu và có mô hình riêng theo ngành.

Production: https://vn-stock-filter.vercel.app

> Đây là công cụ ưu tiên nghiên cứu, không phải hệ thống giao dịch tự động hay khuyến nghị đầu tư.

## Phạm vi MVP

- Toàn bộ ngành trên HOSE, HNX và UPCoM.
- Chỉ cổ phiếu thường của doanh nghiệp đang hoạt động; loại ETF, quỹ, chứng quyền, trái phiếu và mã hủy niêm yết.
- Nguồn dữ liệu là công bố chính thức miễn phí của HOSE, HNX/UPCoM, SSC và trang quan hệ nhà đầu tư của doanh nghiệp.
- Một người dùng được phép truy cập bằng magic link.
- Năm mô hình ngành: `NON_FINANCIAL`, `BANK`, `SECURITIES`, `INSURANCE`, `REAL_ESTATE`.
- Chấm riêng bốn chiều: chất lượng, tăng trưởng, quản trị và sức chống chịu; định giá là một lớp độc lập.

## Kiến trúc

- Next.js App Router ở root repository, triển khai trực tiếp trên Vercel hiện có.
- Supabase Auth, PostgreSQL, Row Level Security và private Storage.
- Python ETL/scoring trong `pipeline/`, chạy theo lịch bằng GitHub Actions.
- Vercel chỉ render UI và thực hiện truy vấn ngắn; tải/đọc PDF-XLS và tính lại điểm không chạy trong Vercel Functions.

## Thiết lập nhanh

1. Tạo Supabase project tại Singapore nếu có thể.
2. Chạy `db/schema.sql`, sau đó `db/supabase_rls.sql` trong SQL editor.
3. Tạo private Storage bucket `official-documents`.
4. Copy `.env.example` thành `.env.local` và điền biến môi trường web.
5. Chạy `npm install && npm run dev`.
6. Trong Vercel, giữ repository hiện tại, đặt Root Directory là repository root và khai báo bốn biến trong `.env.example`.
7. Trong GitHub Secrets, thêm `DATABASE_URL` cho pipeline.

Pipeline local:

```bash
cd pipeline
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m unittest discover -s tests -v
python scripts/refresh.py --mode daily
```

## Cấu trúc repository

- `app/`, `components/`, `lib/`: web app Next.js và Supabase clients.
- `proxy.ts`: refresh session và bảo vệ route phía server.
- `pipeline/src/scoring.py`: chấm điểm và phân loại watchlist có thể kiểm toán.
- `pipeline/src/sources/`: registry nguồn chính thức và kiểm tra URL.
- `pipeline/src/ingestion/`: chuẩn hóa Security Master và Disclosure Registry.
- `pipeline/config/sector_models.yml`: chỉ tiêu và trọng số theo mô hình ngành.
- `pipeline/scripts/refresh.py`: entry point cho job định kỳ.
- `db/schema.sql`: mô hình dữ liệu quan hệ.
- `db/supabase_rls.sql`: quyền truy cập một người dùng và Storage policy.
- `docs/technical_spec.md`: đặc tả kỹ thuật.
- `docs/vercel_deployment.md`: runbook triển khai.

## Nguyên tắc kiểm soát

- Không điền giả dữ liệu thiếu và không tạo điểm mẫu.
- Chỉ công bố điểm khi tỷ lệ bằng chứng đạt ngưỡng cấu hình.
- Veto về quản trị, kiểm toán, trạng thái niêm yết và chất lượng dữ liệu luôn thắng thứ hạng.
- Mọi dữ kiện hiển thị phải truy ngược được tới URL, ngày tài liệu, thời điểm tải và vị trí bằng chứng.
- Các connector live mặc định bị tắt cho tới khi nguồn vượt qua kiểm tra truy cập, điều khoản sử dụng, parser fixture và regression test.

Chi tiết các bước vận hành và biến môi trường nằm trong `docs/vercel_deployment.md`.
