import { createClient } from "@/lib/supabase/server";

export type ScreenerRow = {
  ticker: string;
  exchange: "HOSE" | "HNX" | "UPCOM";
  sector_model: "NON_FINANCIAL" | "BANK" | "SECURITIES" | "INSURANCE" | "REAL_ESTATE";
  quality_score: number | null;
  growth_score: number | null;
  governance_score: number | null;
  resilience_score: number | null;
  valuation_state: "ATTRACTIVE" | "FAIR" | "EXPENSIVE" | "NOT_AVAILABLE" | null;
  evidence_coverage: number;
  watchlist_status: "QUALIFIED" | "RESEARCH" | "MONITOR" | "REVIEW" | "EXCLUDED";
  open_quality_issues: number;
  as_of_date: string;
};

export type ScreenerFilters = {
  exchange?: string;
  sector?: string;
  status?: string;
};

export async function getScreenerRows(filters: ScreenerFilters): Promise<{
  rows: ScreenerRow[];
  error: string | null;
}> {
  const supabase = await createClient();
  let query = supabase
    .from("vw_latest_screener")
    .select("ticker,exchange,sector_model,quality_score,growth_score,governance_score,resilience_score,valuation_state,evidence_coverage,watchlist_status,open_quality_issues,as_of_date")
    .order("governance_score", { ascending: false, nullsFirst: false })
    .order("quality_score", { ascending: false, nullsFirst: false })
    .limit(1000);

  if (["HOSE", "HNX", "UPCOM"].includes(filters.exchange ?? "")) {
    query = query.eq("exchange", filters.exchange!);
  }
  if (["NON_FINANCIAL", "BANK", "SECURITIES", "INSURANCE", "REAL_ESTATE"].includes(filters.sector ?? "")) {
    query = query.eq("sector_model", filters.sector!);
  }
  if (["QUALIFIED", "RESEARCH", "MONITOR", "REVIEW", "EXCLUDED"].includes(filters.status ?? "")) {
    query = query.eq("watchlist_status", filters.status!);
  }

  const { data, error } = await query;
  return {
    rows: (data ?? []) as ScreenerRow[],
    error: error?.message ?? null
  };
}
