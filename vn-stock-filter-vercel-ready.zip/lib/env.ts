const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const publishableKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? "";

export function isSupabaseConfigured(): boolean {
  return Boolean(supabaseUrl && publishableKey);
}

export function getSupabasePublicEnv(): { url: string; publishableKey: string } {
  if (!isSupabaseConfigured()) {
    throw new Error("Supabase environment variables are not configured");
  }
  return { url: supabaseUrl, publishableKey };
}

export function isAllowedEmail(email: string | null | undefined): boolean {
  const allowed = process.env.ALLOWED_EMAIL?.trim().toLowerCase();
  return Boolean(allowed && email?.trim().toLowerCase() === allowed);
}
