import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { isAllowedEmail } from "@/lib/env";

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get("code");
  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      const { data: { user } } = await supabase.auth.getUser();
      if (user && isAllowedEmail(user.email)) {
        return NextResponse.redirect(new URL("/dashboard", request.url));
      }
      await supabase.auth.signOut();
    }
  }
  return NextResponse.redirect(new URL("/login?error=auth", request.url));
}
