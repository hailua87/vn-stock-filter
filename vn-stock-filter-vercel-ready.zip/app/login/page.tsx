import { requestMagicLink } from "./actions";

type LoginProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function LoginPage({ searchParams }: LoginProps) {
  const params = await searchParams;
  const missing = params.configuration === "missing";
  const sent = params.sent === "1";
  const authError = params.error === "auth";

  return (
    <main className="login">
      <section className="login-card">
        <div className="brand">VN Fisher Watchlist</div>
        <h1>Đăng nhập riêng tư</h1>
        <p className="muted">Nhận liên kết đăng nhập một lần qua email đã được cho phép.</p>
        {missing && <p className="notice">Ứng dụng chưa được cấu hình Supabase.</p>}
        {sent && <p className="notice">Nếu email được cho phép, liên kết đăng nhập đã được gửi.</p>}
        {authError && <p className="error">Không thể gửi liên kết đăng nhập. Kiểm tra cấu hình Auth.</p>}
        <form action={requestMagicLink} className="login-form">
          <label htmlFor="email">Email</label>
          <input id="email" name="email" type="email" autoComplete="email" required />
          <button className="button" type="submit" disabled={missing}>Gửi liên kết đăng nhập</button>
        </form>
        <p className="footnote">Ứng dụng phục vụ nghiên cứu cá nhân, không phải khuyến nghị mua hoặc bán.</p>
      </section>
    </main>
  );
}
