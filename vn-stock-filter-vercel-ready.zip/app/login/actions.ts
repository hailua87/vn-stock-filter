"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { isAllowedEmail, isSupabaseConfigured } from "@/lib/env";

export async function requestMagicLink(formData: FormData) {
  if (!isSupabaseConfigured()) redirect("/login?configuration=missing");

  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!isAllowedEmail(email)) redirect("/login?sent=1");

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: { emailRedirectTo: `${siteUrl}/auth/callback` }
  });
  if (error) redirect("/login?error=auth");
  redirect("/login?sent=1");
}
