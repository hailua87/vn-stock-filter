import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "VN Fisher Watchlist",
  description: "Private evidence-led watchlist for HOSE, HNX, and UPCoM"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="vi">
      <body>{children}</body>
    </html>
  );
}
