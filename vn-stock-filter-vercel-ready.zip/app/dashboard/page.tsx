import { signOut } from "@/app/actions";
import { FilterBar } from "@/components/filter-bar";
import { ScreenerTable } from "@/components/screener-table";
import { getScreenerRows } from "@/lib/data";

type DashboardProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const first = (value: string | string[] | undefined) => Array.isArray(value) ? value[0] : value;

export default async function DashboardPage({ searchParams }: DashboardProps) {
  const params = await searchParams;
  const filters = {
    exchange: first(params.exchange),
    sector: first(params.sector),
    status: first(params.status)
  };
  const { rows, error } = await getScreenerRows(filters);
  const scored = rows.filter((row) =>
    [row.quality_score, row.growth_score, row.governance_score, row.resilience_score]
      .every((score) => score !== null)
  ).length;
  const coverage = rows.length
    ? rows.map((row) => row.evidence_coverage).sort((a, b) => a - b)[Math.floor(rows.length / 2)]
    : null;
  const issues = rows.reduce((total, row) => total + Number(row.open_quality_issues), 0);

  return (
    <div className="shell">
      <header className="topbar">
        <div><div className="brand">VN Fisher Watchlist</div><div className="scope">HOSE · HNX · UPCoM</div></div>
        <form action={signOut}><button className="button secondary" type="submit">Đăng xuất</button></form>
      </header>
      <main className="content">
        <div className="headline">
          <div><h1>Fisher research universe</h1><p className="muted">Bộ lọc chất lượng có dẫn chứng; định giá không bù cho quản trị yếu.</p></div>
        </div>
        {error && <div className="error">Không thể tải dữ liệu: {error}</div>}
        <section className="grid">
          <div className="card"><div className="metric-label">Doanh nghiệp</div><div className="metric-value">{rows.length || "—"}</div></div>
          <div className="card"><div className="metric-label">Đã có điểm</div><div className="metric-value">{scored || "—"}</div></div>
          <div className="card"><div className="metric-label">Median coverage</div><div className="metric-value">{coverage === null ? "—" : `${(coverage * 100).toFixed(0)}%`}</div></div>
          <div className="card"><div className="metric-label">Lỗi dữ liệu mở</div><div className="metric-value">{issues || "—"}</div></div>
        </section>
        <section className="panel">
          <div className="panel-head"><div><h2>Research candidates</h2><p className="muted">Chỉ hiển thị dữ liệu đã được pipeline chấp nhận.</p></div></div>
          <FilterBar {...filters} />
          <ScreenerTable rows={rows} />
        </section>
      </main>
    </div>
  );
}
