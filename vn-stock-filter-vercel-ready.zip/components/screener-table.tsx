import type { ScreenerRow } from "@/lib/data";

const score = (value: number | null) => value === null ? "—" : value.toFixed(1);

export function ScreenerTable({ rows }: { rows: ScreenerRow[] }) {
  if (!rows.length) {
    return <div className="empty">Chưa có dữ liệu đã vượt qua QA. Hệ thống không tạo điểm số mẫu.</div>;
  }
  return (
    <div className="table-wrap">
      <table>
        <thead><tr>
          <th>Mã</th><th>Sàn</th><th>Mô hình</th><th>Quality</th><th>Growth</th>
          <th>Governance</th><th>Resilience</th><th>Coverage</th><th>Valuation</th><th>Trạng thái</th><th>Ngày dữ liệu</th>
        </tr></thead>
        <tbody>
          {rows.map((row) => (
            <tr key={`${row.exchange}-${row.ticker}`}>
              <td className="ticker">{row.ticker}</td><td>{row.exchange}</td><td>{row.sector_model}</td>
              <td>{score(row.quality_score)}</td><td>{score(row.growth_score)}</td>
              <td>{score(row.governance_score)}</td><td>{score(row.resilience_score)}</td>
              <td>{(row.evidence_coverage * 100).toFixed(0)}%</td>
              <td>{row.valuation_state ?? "—"}</td>
              <td><span className={`badge ${row.watchlist_status.toLowerCase()}`}>{row.watchlist_status}</span></td>
              <td>{row.as_of_date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
