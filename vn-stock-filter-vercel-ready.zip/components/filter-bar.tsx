type FilterBarProps = {
  exchange?: string;
  sector?: string;
  status?: string;
};

const option = (value: string, label: string) => <option value={value}>{label}</option>;

export function FilterBar({ exchange, sector, status }: FilterBarProps) {
  return (
    <form className="filters" method="get">
      <select name="exchange" defaultValue={exchange ?? ""} aria-label="Sàn">
        {option("", "Tất cả sàn")}{option("HOSE", "HOSE")}{option("HNX", "HNX")}{option("UPCOM", "UPCoM")}
      </select>
      <select name="sector" defaultValue={sector ?? ""} aria-label="Mô hình ngành">
        {option("", "Tất cả mô hình ngành")}{option("NON_FINANCIAL", "Phi tài chính")}
        {option("BANK", "Ngân hàng")}{option("SECURITIES", "Chứng khoán")}
        {option("INSURANCE", "Bảo hiểm")}{option("REAL_ESTATE", "Bất động sản")}
      </select>
      <select name="status" defaultValue={status ?? ""} aria-label="Trạng thái">
        {option("", "Tất cả trạng thái")}{option("QUALIFIED", "Qualified")}
        {option("RESEARCH", "Research")}{option("MONITOR", "Monitor")}
        {option("REVIEW", "Review")}{option("EXCLUDED", "Excluded")}
      </select>
      <button className="button secondary" type="submit">Áp dụng</button>
    </form>
  );
}
