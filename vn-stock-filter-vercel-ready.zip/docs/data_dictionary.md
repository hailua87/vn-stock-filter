# Data dictionary

## Core entities

### `company`

| Field | Type | Definition |
|---|---|---|
| `company_id` | UUID | Stable internal company key |
| `legal_name` | text | Legal issuer name from official disclosure |
| `short_name` | text | Official short name |
| `tax_code` | text | Tax identifier when officially available |
| `industry_code` | text | Source industry classification code |
| `industry_name` | text | Source industry name |
| `sector_model` | enum | Calculation engine: NON_FINANCIAL, BANK, SECURITIES, INSURANCE, REAL_ESTATE |
| `official_website` | URL | Issuer's official website or IR page |

### `security`

| Field | Type | Definition |
|---|---|---|
| `security_id` | UUID | Versioned security key |
| `company_id` | UUID | Issuer link |
| `ticker` | text | Official trading code |
| `exchange` | enum | HOSE, HNX, UPCOM |
| `security_type` | text | Must equal ORDINARY_SHARE for the universe |
| `listing_status` | text | Active, warning, controlled, suspended, or delisted status |
| `shares_outstanding` | numeric | Outstanding ordinary shares as of the source date |
| `free_float` | numeric | Free-float shares or ratio, preserving source definition |
| `valid_from` / `valid_to` | date | Effective-dated membership and attributes |

### `disclosure_document`

| Field | Type | Definition |
|---|---|---|
| `document_id` | UUID | Immutable evidence identifier |
| `source_code` | text | Registry code such as HOSE, HNX, UPCOM, SSC, ISSUER_IR |
| `source_url` | URL | Direct official source link |
| `document_type` | text | Financial statement, annual report, governance report, event, price file, etc. |
| `published_at` | timestamp | Official publication time when available |
| `retrieved_at` | timestamp | UTC retrieval time |
| `reporting_period_end` | date | Period end described by the document |
| `sha256` | text | Content checksum |
| `parser_status` | enum | PENDING, PARSED, PARTIAL, FAILED, MANUAL_REVIEW |
| `storage_path` | text | Private object location; never a public URL |

### `financial_fact`

| Field | Type | Definition |
|---|---|---|
| `metric_code` | text | Governed canonical metric code |
| `period_type` | enum | QUARTER, YEAR, TTM |
| `period_start` / `period_end` | date | Economic reporting period |
| `value` | numeric | Source value before presentation formatting |
| `currency` | text | Currency code when applicable |
| `unit_scale` | numeric | Multiplier required to reach base unit |
| `statement_scope` | enum | CONSOLIDATED or SEPARATE |
| `audit_status` | enum | AUDITED, REVIEWED, UNAUDITED |
| `restatement_version` | integer | Source revision order |
| `evidence_locator` | text | Sheet/cell, page/table, or HTML locator |
| `extraction_method` | enum | XLS, HTML, PDF, MANUAL |
| `confidence` | decimal | Extraction confidence, not business confidence |
| `accepted` | boolean | Passed validation and is eligible for calculations |

### `qualitative_assessment`

| Field | Type | Definition |
|---|---|---|
| `criterion_code` | text | Governed Fisher criterion identifier |
| `score` | numeric | 0–100 only when evidence supports scoring |
| `assessment_status` | enum | VERIFIED, PENDING_REVIEW, INSUFFICIENT_EVIDENCE, REJECTED |
| `rationale` | text | Concise analytical conclusion |
| `document_id` | UUID | Primary evidence link |
| `evidence_locator` | text | Exact page/section/table reference |
| `assessed_at` | timestamp | Review time |
| `expires_at` | timestamp | Mandatory revalidation date |

### `score_snapshot`

| Field | Type | Definition |
|---|---|---|
| `score_version` | text | Immutable scoring configuration version |
| `quality_score` | numeric | Sector-aware business-quality score |
| `growth_score` | numeric | Sustainable-growth score |
| `governance_score` | numeric | Verified qualitative/governance score |
| `resilience_score` | numeric | Balance-sheet and downside-resilience score |
| `evidence_coverage` | decimal | Evidenced weight divided by configured weight |
| `valuation_state` | enum | ATTRACTIVE, FAIR, EXPENSIVE, NOT_AVAILABLE |
| `watchlist_status` | enum | QUALIFIED, RESEARCH, MONITOR, REVIEW, EXCLUDED |
| `veto_reasons` | JSON | Active hard-veto rule codes and evidence |
| `metric_details` | JSON | Input values, weights, transformations, and missing metrics |

## Canonical metric families

| Family | Examples | Notes |
|---|---|---|
| Income statement | revenue, gross_profit, operating_profit, net_profit | Preserve consolidated/separate scope |
| Balance sheet | total_assets, equity, cash, debt, inventory, receivables | Financial-sector taxonomy differs |
| Cash flow | cfo, capex, free_cash_flow | Do not force cash conversion on banks/insurers |
| Shares | shares_outstanding, weighted_average_shares | Required for dilution and per-share analysis |
| Banking | customer_loans, deposits, npl, provisions, nim, car | Record regulatory definition and period |
| Securities | margin_loans, brokerage_revenue, proprietary_result, capital_adequacy | Separate recurring and market-sensitive earnings |
| Insurance | gross_premium, net_premium, claims, reserves, solvency_margin | Life/non-life definitions must not be mixed |
| Real estate | inventory, presales, unearned_revenue, project_debt, bond_maturity | Legal-pipeline measures require qualitative evidence |

## Null policy

- `NULL` means unavailable or not yet verified.
- Zero means an evidenced numeric zero.
- Not applicable is carried in metric metadata and excluded from eligible weight.
- Missing and not applicable must never be combined.

