# Approved-source registry

This registry is a design baseline. A connector remains disabled until its access method, terms, schema, and parser tests are documented and approved.

| Code | Owner | Purpose | Official entry point | Initial mode |
|---|---|---|---|---|
| HOSE | Ho Chi Minh Stock Exchange | Listing status, disclosures, issuer reports | https://www.hsx.vn/ | Discovery + manual fallback |
| HNX | Hanoi Stock Exchange | HNX listing status and disclosures | https://hnx.vn/ | Discovery + manual fallback |
| UPCOM | Hanoi Stock Exchange | UPCoM disclosures and issuer information | https://www.upcom.hnx.vn/ | Discovery + manual fallback |
| SSC | State Securities Commission | Public-company disclosures and regulatory events | https://congbothongtin.ssc.gov.vn/ | Discovery + manual fallback |
| ISSUER_IR | Listed issuer | Annual reports, financial statements, governance materials | Company-specific official domain | Allowlist only |

## Source precedence

1. Exchange or SSC disclosure with an attached issuer document.
2. The same document on the issuer's official IR domain.
3. Manual upload of the unchanged official document when automated retrieval fails.

Third-party news, financial portals, social media, analyst estimates, and scraped reposts are excluded from the governed dataset.

## Connector acceptance checklist

- Official domain and ownership verified.
- Terms and automated-access constraints reviewed.
- Rate limit and retry policy configured.
- Publication timestamp and reporting period mapped.
- Document hash and duplicate rules tested.
- At least five representative fixtures pass.
- Changed-document and restatement behavior tested.
- Parser failure creates a visible quality issue.
- Manual fallback preserves the same metadata contract.

