# Vercel web application

The repository root is the Vercel project root. This document describes the web layer only.

## Local development

1. Copy `.env.example` to `.env.local`.
2. Set the Supabase project URL, publishable key, site URL, and single allowed email.
3. Run `npm install`.
4. Run `npm run dev`.

## Vercel settings

- Framework preset: Next.js
- Root Directory: repository root (`.`)
- Production domain: `https://vn-stock-filter.vercel.app`
- Production branch: `main`
- Region: Singapore (`sin1`)
- Environment variables: copy the four names from `.env.example`
- Never add the Supabase service-role key to `NEXT_PUBLIC_*` variables.

Heavy document processing is intentionally excluded from this deployment. GitHub Actions runs the Python pipeline and writes accepted results to Supabase with a server-side secret.
