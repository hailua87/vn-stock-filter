# Technical specification

## 1. Objective

Build a private online application that prioritizes Vietnamese listed companies for deeper research using Philip Fisher's principles. The system must be evidence-led, sector-aware, reproducible, and explicit about missing data.

It must not issue automated buy or sell recommendations.

## 2. Confirmed requirements

| Dimension | Requirement |
|---|---|
| Markets | HOSE, HNX, UPCoM |
| Industries | All industries from the first release |
| Sources | Official public disclosures only |
| Access | One private user |
| Delivery | Next.js online web application on Vercel |
| Repository | Personal private GitHub repository |
| Hosting | External cloud |
| Refresh | Daily event/price refresh; quarterly fundamentals; event-driven governance review |

## 3. Non-goals

- Order execution or brokerage integration
- Intraday trading signals
- Untraceable generative-AI estimates
- Redistribution of licensed third-party market data
- Automatic assignment of neutral values to missing evidence

## 4. System components

### 4.1 Ingestion

Source connectors discover official documents and market files. Each connector must have:

- source owner and approved domain;
- document types and expected frequency;
- request and retry limits;
- schema or parser contract;
- terms-of-use review status;
- fallback manual-upload route;
- fixture documents and regression tests.

No connector is production-enabled until those controls pass.

Phase 1 implements this governance through `config/sources.yml`, the official-host validator, Security Master normalization, Disclosure Registry normalization, document-link discovery, and a manual JSONL validation fallback. All live connectors remain disabled until approved.

### 4.2 Raw evidence

Documents are stored unchanged in a private bucket. Metadata includes URL, publisher, publication time, retrieval time, MIME type, SHA-256, reporting period, and parser status. Duplicate URLs with changed content create a new evidence version rather than silently overwriting history.

### 4.3 Normalization

Financial facts use a long model:

`company × metric × period × statement scope × restatement version × evidence document`

Consolidated statements take precedence over separate statements for group analysis. Audited/reviewed results supersede unaudited results for the same period, while prior versions remain available for audit.

### 4.4 Sector scoring

All companies map to one of five calculation engines. Banks, securities firms, insurers, and real-estate developers do not use the generic cash-flow or leverage formula where it is economically inappropriate.

Metrics are converted to 0–100 using a combination of:

- sector percentile at the same reporting date;
- company historical stability;
- absolute risk thresholds where economically justified;
- explicit direction, where higher or lower is better.

### 4.5 Qualitative review

Fisher criteria use four states:

- `VERIFIED`: sufficient evidence and human approval;
- `PENDING_REVIEW`: evidence exists but has not been approved;
- `INSUFFICIENT_EVIDENCE`: no defensible conclusion;
- `REJECTED`: evidence is irrelevant or unreliable.

Only verified assessments contribute to a published governance or qualitative score.

### 4.6 Valuation

Valuation remains independent from quality. Sector-appropriate methods include historical and peer multiples, free-cash-flow yield where meaningful, and reverse-DCF assumptions. The first release records a state of `ATTRACTIVE`, `FAIR`, `EXPENSIVE`, or `NOT_AVAILABLE`; it does not create a trade signal.

## 5. Watchlist state machine

| State | Meaning |
|---|---|
| QUALIFIED | Quality, growth, governance, and coverage thresholds passed; no veto |
| RESEARCH | Insufficient evidence or incomplete review |
| MONITOR | Quality acceptable but valuation/timing or one non-critical condition requires monitoring |
| REVIEW | Quality or governance deterioration requires thesis review |
| EXCLUDED | A hard veto is active |

## 6. Data-quality gates

Mandatory checks include:

- unique ticker/exchange validity by date;
- no overlapping security validity periods;
- period continuity and fiscal-year alignment;
- statement-scope consistency;
- unit and currency normalization;
- duplicate/restatement control;
- accounting equation checks where fields are available;
- cash-flow and profit reconciliation flags;
- source/evidence presence for every accepted fact;
- stale assessment and stale price detection;
- cross-source conflicts reported, never silently resolved.

## 7. Security

- Private repository and authenticated production app.
- Secrets stored outside source control.
- Supabase publishable key may be used by the browser only with Row Level Security enabled.
- Database/service-role credentials never exposed to the browser or `NEXT_PUBLIC_*` variables.
- Private raw-document bucket.
- Least-privilege database role for the app.
- Row-level security and an explicit `app_user` allowlist enabled before data access.
- No employer-confidential or personal data is permitted.

## 8. Operations

### Daily job

- refresh security/listing status;
- discover new disclosures;
- retrieve accepted price files;
- open data-quality issues;
- recompute affected valuation states and watchlist rows.

### Quarterly job

- discover and parse financial statements;
- resolve restatements;
- calculate sector metrics;
- publish scores only after coverage and QA gates pass.

### Annual/event-driven job

- refresh annual reports and governance documents;
- expire stale qualitative assessments;
- queue management, strategy, audit, and related-party changes for review.

## 9. Deployment

The production architecture uses a single repository. The Next.js App Router project lives at repository root for direct deployment by the existing Vercel project; Python code lives under `pipeline/` and executes through scheduled GitHub Actions. Supabase provides cookie-based Auth, PostgreSQL, and private document Storage.

Vercel handles only UI rendering and short database requests. Source discovery, document download, PDF/XLS parsing, QA, and score recomputation stay outside interactive functions. Manual refresh remains available because official sites may change markup, enforce rate controls, or publish non-machine-readable documents.

Vercel must be configured with the repository root as the Root Directory and a region close to the Supabase project. Authentication uses a single allowed email plus the `app_user` database allowlist; Row Level Security remains the final authorization layer.

## 10. Acceptance criteria

- The app loads privately with an empty, non-fabricated state.
- Every ranked row has at least 70% evidenced scoring weight.
- Every displayed metric links to an accepted financial fact and source document.
- Hard vetoes override all numeric rankings.
- Sector models produce independent, reviewable calculations.
- Errors create visible data-quality issues rather than disappearing from the pipeline.
- The scoring module passes automated tests.
