# Phase 1 — Security Master and Disclosure Registry

## Objective

Create a governed universe of active ordinary shares on HOSE, HNX, and UPCoM and a traceable inbox of official disclosures. This phase deliberately precedes financial-statement parsing because every downstream fact requires a stable issuer/security key and evidence record.

## Delivered controls

- Versioned registry of official source owners, entry points, allowed hosts, artifact types, and connector status.
- Exact-host/subdomain validation that rejects lookalike and non-HTTPS URLs.
- Security normalization for ticker, exchange, ordinary-share scope, listing status, effective date, and shares outstanding.
- Disclosure normalization for title, document type, publication time, reporting period, URL, and SHA-256.
- Deterministic disclosure deduplication using URL plus content hash.
- HTML link discovery that accepts only allowlisted official document URLs.
- JSONL validation route for manual fallback without writing directly to production tables.
- Unit tests for source allowlists, universe exclusions, data validation, and deduplication.

## Why live connectors remain disabled

The official sites differ in page structure, JavaScript requirements, attachment hosting, and file formats. Enabling automation before reviewing access constraints and establishing archived fixtures would create silent coverage gaps. Each source must pass the connector acceptance checklist in `docs/source_registry.md`.

## Manual manifest contract

Each line is one JSON object with `record_type` equal to `security` or `disclosure`. Records must contain an official HTTPS URL matching the registered source. The validator prints normalized accepted records and returns a non-zero status when any line is rejected.

No manifest bypasses document hashing, evidence capture, or database QA in the eventual production loader.

## Next engineering step

For each exchange, archive representative official index pages and attachments, document access constraints, build a source-specific adapter, and run regression tests against the fixtures. Start with issuer/security universe coverage before price history or financial statements.

