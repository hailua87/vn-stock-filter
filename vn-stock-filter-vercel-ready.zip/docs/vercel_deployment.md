# Vercel deployment runbook

## Target architecture

- Vercel: Next.js user interface and short database requests.
- Supabase: Auth, PostgreSQL, private document storage, and row-level security.
- GitHub Actions: Python ingestion, parsing, QA, and score recomputation.

## 1. Create Supabase project

1. Select a region close to the Vercel function region, preferably Singapore.
2. Apply `db/schema.sql`.
3. Apply `db/supabase_rls.sql`.
4. Create a private Storage bucket named `official-documents`.
5. Configure the application URL and callback URL ending in `/auth/callback`.
6. Disable unrestricted public sign-up after the allowed personal account is created.

## 2. GitHub repository

Use the existing `hailua87/vn-stock-filter` repository so the production domain remains `https://vn-stock-filter.vercel.app`. Never commit `.env`, `.env.local`, database passwords, service-role keys, or downloaded source documents. GitHub Actions receives the pipeline database credential through repository Secrets.

## 3. Import into Vercel

1. Keep the existing Vercel project connected to `hailua87/vn-stock-filter`.
2. Set Root Directory to the repository root (`.`). Remove the previous static output-directory override if one remains in Project Settings.
3. Confirm Next.js framework detection.
4. Add `NEXT_PUBLIC_SUPABASE_URL`.
5. Add `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
6. Add `NEXT_PUBLIC_SITE_URL=https://vn-stock-filter.vercel.app`.
7. Add `ALLOWED_EMAIL` using the one authorized account.
8. Deploy and add the production callback URL to Supabase Auth.

## 4. Activate the user

After the first successful Auth login, insert the corresponding `auth.users.id` into `public.app_user`. Do not hard-code a user UUID in repository SQL.

## 5. Configure pipeline secrets

Add the server-side database connection to GitHub Secrets as `DATABASE_URL`. If Storage uploads are later enabled, add the server-side storage credential as a separate secret. Never use a service-role key in a `NEXT_PUBLIC_*` variable.

## 6. Verification checklist

- Anonymous request redirects to `/login`.
- An unauthorized email does not receive application access.
- Authorized user can query `vw_latest_screener`.
- Browser cannot insert financial facts or scores.
- Browser can maintain only permitted watchlist and qualitative-review records.
- Documents are inaccessible without an authenticated signed request.
- Empty data displays an explicit governed-empty state.
- GitHub Actions can write through the server-side connection.
- Vercel contains no heavy PDF/XLS parsing route.

## Official references

- Vercel monorepo Root Directory: https://vercel.com/docs/monorepos
- Vercel Function duration: https://vercel.com/docs/functions/configuring-functions/duration
- Supabase Auth with Next.js: https://supabase.com/docs/guides/auth/quickstarts/nextjs
- Supabase Row Level Security: https://supabase.com/docs/guides/database/postgres/row-level-security
