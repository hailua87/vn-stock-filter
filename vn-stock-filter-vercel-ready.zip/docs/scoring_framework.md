# Scoring framework

## 1. Principles

1. Rank evidence quality before company quality.
2. Keep valuation separate from business quality.
3. Compare economically similar companies.
4. Never let a strong metric compensate for a hard governance or audit veto.
5. Preserve every transformation used in a score snapshot.

## 2. Published dimensions

| Dimension | Range | Interpretation |
|---|---:|---|
| Business Quality | 0–100 | Profitability, economics, stability, and operating capability |
| Growth Sustainability | 0–100 | Multi-year growth, repeatability, and financing support |
| Governance Confidence | 0–100 | Candor, integrity, management depth, controls, and verified evidence |
| Financial Resilience | 0–100 | Ability to survive adverse operating and funding conditions |
| Valuation State | categorical | ATTRACTIVE, FAIR, EXPENSIVE, NOT_AVAILABLE |

## 3. Evidence coverage

For a score dimension:

`coverage = evidenced eligible weight / total eligible weight`

The default publication threshold is 70%. Below that threshold, the score is withheld and the company remains in `RESEARCH`. Missing metrics do not receive a value of 50.

## 4. Standard transformations

- Sector percentile: winsorize at the 5th/95th percentile and map rank to 0–100.
- Stability: penalize coefficient of variation, negative years, and large drawdowns.
- Direction: explicitly configure whether higher or lower is better.
- Growth: use CAGR only when endpoints are positive and economically comparable; otherwise use a documented alternative.
- Restatements: use the latest accepted version and retain prior versions.
- Outliers: flag before winsorization and retain original values in metric details.

## 5. Governance evidence scale

| Score band | Required interpretation |
|---:|---|
| 80–100 | Strong multi-source evidence; consistent behavior through adverse periods |
| 60–79 | Generally positive evidence with identifiable limitations |
| 40–59 | Mixed evidence or material uncertainty |
| 1–39 | Repeated negative evidence or weak controls |
| NULL | Insufficient verified evidence |

## 6. Hard vetoes

Initial veto rules are:

- delisted or indefinitely suspended;
- adverse audit opinion;
- disclaimer of audit opinion;
- unresolved material going-concern uncertainty;
- unresolved serious disclosure breach;
- critical source conflict that invalidates the score.

Vetoes must include document evidence and an expiry/review condition. A warning label alone is not enough unless mapped to a governed rule.

## 7. Watchlist classification

| Status | Default decision rule |
|---|---|
| QUALIFIED | Quality ≥75, Growth ≥70, Governance ≥70, Resilience ≥65, coverage ≥70%, no veto, valuation not EXPENSIVE |
| MONITOR | Core quality passes but valuation is EXPENSIVE or thresholds are only partially met |
| RESEARCH | One or more required dimensions are unpublished because evidence is incomplete |
| REVIEW | Quality or Governance <60, Resilience <50, or a material deterioration event is open |
| EXCLUDED | One or more active hard vetoes |

Thresholds are configuration defaults, not claims of predictive validity. They must be backtested without survivorship or look-ahead bias before investment use.

## 8. Sector separation

- Non-financial companies use ROIC, margins, cash conversion, leverage, and operating efficiency.
- Banks use asset quality, capital, funding, NIM, credit costs, and efficiency.
- Securities companies use capital adequacy, margin-loan quality, recurring revenue, and proprietary-risk exposure.
- Insurers use underwriting economics, reserve adequacy, solvency, and investment quality.
- Real-estate companies use cash conversion, inventory/project quality, legal pipeline, maturity profile, and related-party risk.
