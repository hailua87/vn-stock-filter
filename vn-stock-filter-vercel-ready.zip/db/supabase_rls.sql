-- Apply after db/schema.sql inside a Supabase project.

CREATE TABLE IF NOT EXISTS public.app_user (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.app_user ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_app_user()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.app_user
    WHERE user_id = auth.uid() AND is_active = TRUE
  );
$$;

REVOKE ALL ON FUNCTION public.is_app_user() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_app_user() TO authenticated;

CREATE POLICY app_user_read_self ON public.app_user
FOR SELECT TO authenticated
USING (user_id = auth.uid() AND is_active = TRUE);

ALTER TABLE public.company ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.security ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ingestion_run ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.disclosure_document ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financial_fact ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.market_price_daily ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.qualitative_assessment ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.data_quality_issue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.score_snapshot ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.watchlist_item ENABLE ROW LEVEL SECURITY;

CREATE POLICY company_read ON public.company FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY security_read ON public.security FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY ingestion_run_read ON public.ingestion_run FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY disclosure_read ON public.disclosure_document FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY financial_fact_read ON public.financial_fact FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY market_price_read ON public.market_price_daily FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY qualitative_read ON public.qualitative_assessment FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY quality_issue_read ON public.data_quality_issue FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY score_read ON public.score_snapshot FOR SELECT TO authenticated USING (public.is_app_user());
CREATE POLICY watchlist_read ON public.watchlist_item FOR SELECT TO authenticated USING (public.is_app_user());

CREATE POLICY qualitative_insert ON public.qualitative_assessment FOR INSERT TO authenticated
WITH CHECK (public.is_app_user());
CREATE POLICY qualitative_update ON public.qualitative_assessment FOR UPDATE TO authenticated
USING (public.is_app_user()) WITH CHECK (public.is_app_user());

CREATE POLICY watchlist_insert ON public.watchlist_item FOR INSERT TO authenticated
WITH CHECK (public.is_app_user());
CREATE POLICY watchlist_update ON public.watchlist_item FOR UPDATE TO authenticated
USING (public.is_app_user()) WITH CHECK (public.is_app_user());
CREATE POLICY watchlist_delete ON public.watchlist_item FOR DELETE TO authenticated
USING (public.is_app_user());

ALTER VIEW public.vw_latest_screener SET (security_invoker = true);
GRANT SELECT ON public.vw_latest_screener TO authenticated;

-- Create a private Storage bucket named official-documents in the Supabase dashboard first.
CREATE POLICY official_documents_read ON storage.objects
FOR SELECT TO authenticated
USING (bucket_id = 'official-documents' AND public.is_app_user());

-- After the first successful Auth login, an administrator must activate the user:
-- INSERT INTO public.app_user(user_id)
-- SELECT id FROM auth.users WHERE email = 'YOUR_ALLOWED_EMAIL';
