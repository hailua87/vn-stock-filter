CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS company (
    company_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    legal_name TEXT NOT NULL,
    short_name TEXT,
    tax_code TEXT,
    official_website TEXT,
    industry_code TEXT,
    industry_name TEXT,
    sector_model TEXT NOT NULL CHECK (
        sector_model IN ('NON_FINANCIAL', 'BANK', 'SECURITIES', 'INSURANCE', 'REAL_ESTATE')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS security (
    security_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES company(company_id),
    ticker TEXT NOT NULL,
    exchange TEXT NOT NULL CHECK (exchange IN ('HOSE', 'HNX', 'UPCOM')),
    security_type TEXT NOT NULL DEFAULT 'ORDINARY_SHARE',
    listing_status TEXT NOT NULL,
    listed_from DATE,
    listed_to DATE,
    shares_outstanding NUMERIC,
    free_float NUMERIC,
    source_document_id UUID,
    valid_from DATE NOT NULL,
    valid_to DATE,
    UNIQUE (ticker, exchange, valid_from)
);

CREATE TABLE IF NOT EXISTS ingestion_run (
    run_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_code TEXT NOT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    status TEXT NOT NULL CHECK (status IN ('RUNNING', 'SUCCEEDED', 'PARTIAL', 'FAILED')),
    records_read INTEGER NOT NULL DEFAULT 0,
    records_accepted INTEGER NOT NULL DEFAULT 0,
    records_rejected INTEGER NOT NULL DEFAULT 0,
    error_summary TEXT
);

CREATE TABLE IF NOT EXISTS disclosure_document (
    document_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID REFERENCES company(company_id),
    ticker TEXT,
    source_code TEXT NOT NULL,
    source_url TEXT NOT NULL,
    document_type TEXT NOT NULL,
    title TEXT NOT NULL,
    published_at TIMESTAMPTZ,
    retrieved_at TIMESTAMPTZ NOT NULL,
    reporting_period_end DATE,
    storage_path TEXT,
    sha256 TEXT NOT NULL,
    mime_type TEXT,
    parser_status TEXT NOT NULL CHECK (
        parser_status IN ('PENDING', 'PARSED', 'PARTIAL', 'FAILED', 'MANUAL_REVIEW')
    ),
    UNIQUE (source_url, sha256)
);

ALTER TABLE security
    ADD CONSTRAINT security_source_document_fk
    FOREIGN KEY (source_document_id) REFERENCES disclosure_document(document_id);

CREATE TABLE IF NOT EXISTS financial_fact (
    fact_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES company(company_id),
    metric_code TEXT NOT NULL,
    period_type TEXT NOT NULL CHECK (period_type IN ('QUARTER', 'YEAR', 'TTM')),
    period_start DATE,
    period_end DATE NOT NULL,
    value NUMERIC NOT NULL,
    currency TEXT,
    unit_scale NUMERIC NOT NULL DEFAULT 1,
    statement_scope TEXT NOT NULL CHECK (statement_scope IN ('CONSOLIDATED', 'SEPARATE')),
    audit_status TEXT NOT NULL CHECK (audit_status IN ('AUDITED', 'REVIEWED', 'UNAUDITED')),
    restatement_version INTEGER NOT NULL DEFAULT 1,
    document_id UUID NOT NULL REFERENCES disclosure_document(document_id),
    evidence_locator TEXT,
    extraction_method TEXT NOT NULL CHECK (extraction_method IN ('XLS', 'HTML', 'PDF', 'MANUAL')),
    confidence NUMERIC NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    accepted BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (
        company_id, metric_code, period_type, period_end, statement_scope,
        restatement_version, document_id
    )
);

CREATE TABLE IF NOT EXISTS market_price_daily (
    security_id UUID NOT NULL REFERENCES security(security_id),
    trading_date DATE NOT NULL,
    open_price NUMERIC,
    high_price NUMERIC,
    low_price NUMERIC,
    close_price NUMERIC NOT NULL,
    adjusted_close NUMERIC,
    volume NUMERIC,
    trading_value NUMERIC,
    source_code TEXT NOT NULL,
    retrieved_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (security_id, trading_date)
);

CREATE TABLE IF NOT EXISTS qualitative_assessment (
    assessment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES company(company_id),
    criterion_code TEXT NOT NULL,
    score NUMERIC CHECK (score BETWEEN 0 AND 100),
    assessment_status TEXT NOT NULL CHECK (
        assessment_status IN ('VERIFIED', 'PENDING_REVIEW', 'INSUFFICIENT_EVIDENCE', 'REJECTED')
    ),
    rationale TEXT,
    document_id UUID REFERENCES disclosure_document(document_id),
    evidence_locator TEXT,
    assessed_at TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ,
    UNIQUE (company_id, criterion_code, assessed_at)
);

CREATE TABLE IF NOT EXISTS data_quality_issue (
    issue_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID REFERENCES company(company_id),
    document_id UUID REFERENCES disclosure_document(document_id),
    severity TEXT NOT NULL CHECK (severity IN ('INFO', 'WARNING', 'BLOCKER')),
    rule_code TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('OPEN', 'RESOLVED', 'ACCEPTED_EXCEPTION')),
    detected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS score_snapshot (
    score_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES company(company_id),
    as_of_date DATE NOT NULL,
    score_version TEXT NOT NULL,
    quality_score NUMERIC CHECK (quality_score BETWEEN 0 AND 100),
    growth_score NUMERIC CHECK (growth_score BETWEEN 0 AND 100),
    governance_score NUMERIC CHECK (governance_score BETWEEN 0 AND 100),
    resilience_score NUMERIC CHECK (resilience_score BETWEEN 0 AND 100),
    evidence_coverage NUMERIC NOT NULL CHECK (evidence_coverage BETWEEN 0 AND 1),
    valuation_state TEXT CHECK (
        valuation_state IN ('ATTRACTIVE', 'FAIR', 'EXPENSIVE', 'NOT_AVAILABLE')
    ),
    watchlist_status TEXT NOT NULL CHECK (
        watchlist_status IN ('QUALIFIED', 'RESEARCH', 'MONITOR', 'REVIEW', 'EXCLUDED')
    ),
    veto_reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
    metric_details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id, as_of_date, score_version)
);

CREATE TABLE IF NOT EXISTS watchlist_item (
    watchlist_item_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES company(company_id),
    thesis TEXT,
    key_risks TEXT,
    invalidation_conditions TEXT,
    target_review_date DATE,
    user_status TEXT NOT NULL CHECK (user_status IN ('ACTIVE', 'PAUSED', 'ARCHIVED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_id)
);

CREATE OR REPLACE VIEW vw_latest_screener AS
WITH latest_security AS (
    SELECT DISTINCT ON (company_id)
        company_id, ticker, exchange
    FROM security
    WHERE valid_to IS NULL
      AND security_type = 'ORDINARY_SHARE'
    ORDER BY company_id, valid_from DESC
),
latest_score AS (
    SELECT DISTINCT ON (company_id)
        company_id, as_of_date, quality_score, growth_score,
        governance_score, resilience_score, valuation_state, evidence_coverage, watchlist_status
    FROM score_snapshot
    ORDER BY company_id, as_of_date DESC, created_at DESC
)
SELECT s.ticker,
       s.exchange,
       c.sector_model,
       sc.quality_score,
       sc.growth_score,
       sc.governance_score,
       sc.resilience_score,
       sc.valuation_state,
       sc.evidence_coverage,
       sc.watchlist_status,
       COUNT(q.issue_id) FILTER (WHERE q.status = 'OPEN') AS open_quality_issues,
       sc.as_of_date
FROM latest_security s
JOIN company c ON c.company_id = s.company_id
JOIN latest_score sc ON sc.company_id = c.company_id
LEFT JOIN data_quality_issue q ON q.company_id = c.company_id
GROUP BY s.ticker, s.exchange, c.sector_model, sc.quality_score,
         sc.growth_score, sc.governance_score, sc.resilience_score, sc.valuation_state,
         sc.evidence_coverage, sc.watchlist_status, sc.as_of_date;
