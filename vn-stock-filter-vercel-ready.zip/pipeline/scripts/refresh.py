from __future__ import annotations

import argparse
import datetime as dt
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.sources.registry import load_source_registry


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a governed refresh job.")
    parser.add_argument(
        "--mode",
        choices=["daily", "quarterly", "full"],
        default="daily",
        help="daily=prices/status/disclosures; quarterly=financial facts; full=all",
    )
    parser.add_argument(
        "--registry",
        default=str(ROOT / "config" / "sources.yml"),
        help="Path to the governed source registry",
    )
    args = parser.parse_args()

    registry = load_source_registry(Path(args.registry))
    enabled = [source.code for source in registry.values() if source.automated_enabled]
    print(
        f"{dt.datetime.now(dt.timezone.utc).isoformat()} "
        f"refresh mode={args.mode} sources={len(registry)} "
        f"automated_enabled={len(enabled)} status="
        f"{'READY' if enabled else 'NO_APPROVED_CONNECTORS'}"
    )
    return 0



if __name__ == "__main__":
    raise SystemExit(main())
