from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.ingestion.disclosures import normalize_disclosure_record
from src.ingestion.security_master import normalize_security_record
from src.sources.registry import load_source_registry


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate an official-source JSONL manifest")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--registry", type=Path, default=ROOT / "config" / "sources.yml")
    args = parser.parse_args()

    registry = load_source_registry(args.registry)
    accepted = 0
    rejected = 0

    for line_number, line in enumerate(args.manifest.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            payload = json.loads(line)
            record_type = str(payload.pop("record_type", "")).lower()
            if record_type == "security":
                normalized = normalize_security_record(payload, registry)
            elif record_type == "disclosure":
                normalized = normalize_disclosure_record(payload, registry)
            else:
                raise ValueError("record_type must be security or disclosure")
            print(json.dumps(normalized.to_dict(), ensure_ascii=False, default=str))
            accepted += 1
        except (ValueError, json.JSONDecodeError) as exc:
            print(f"line={line_number} status=REJECTED reason={exc}", file=sys.stderr)
            rejected += 1

    print(f"accepted={accepted} rejected={rejected}", file=sys.stderr)
    return 1 if rejected else 0


if __name__ == "__main__":
    raise SystemExit(main())

