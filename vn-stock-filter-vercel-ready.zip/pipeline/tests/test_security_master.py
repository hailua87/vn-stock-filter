import unittest
from pathlib import Path

from src.ingestion.security_master import normalize_security_record
from src.sources.registry import load_source_registry


ROOT = Path(__file__).resolve().parents[1]


class SecurityMasterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = load_source_registry(ROOT / "config" / "sources.yml")

    def test_normalizes_hsx_alias_and_number(self):
        record = normalize_security_record(
            {
                "source_code": "HOSE",
                "source_url": "https://www.hsx.vn/security-list",
                "ticker": " abc ",
                "exchange": "HSX",
                "legal_name": "  Example   Company  ",
                "security_type": "ordinary_share",
                "listing_status": "normal",
                "shares_outstanding": "1,000,000",
                "effective_date": "2026-09-19",
            },
            self.registry,
        )
        self.assertEqual(record.ticker, "ABC")
        self.assertEqual(record.exchange, "HOSE")
        self.assertEqual(str(record.shares_outstanding), "1000000")

    def test_excludes_non_ordinary_security(self):
        with self.assertRaises(ValueError):
            normalize_security_record(
                {
                    "source_code": "HNX",
                    "source_url": "https://hnx.vn/security-list",
                    "ticker": "FND",
                    "exchange": "HNX",
                    "legal_name": "Example Fund",
                    "security_type": "ETF",
                    "listing_status": "ACTIVE",
                    "effective_date": "2026-09-19",
                },
                self.registry,
            )


if __name__ == "__main__":
    unittest.main()

