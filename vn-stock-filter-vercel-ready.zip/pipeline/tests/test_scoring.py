import unittest

from src.scoring import classify_watchlist, weighted_score


class WeightedScoreTests(unittest.TestCase):
    def test_complete_weighted_score(self):
        result = weighted_score(
            {"a": 80, "b": 60}, {"a": 0.75, "b": 0.25}, minimum_coverage=0.70
        )
        self.assertEqual(result.score, 75.0)
        self.assertEqual(result.evidence_coverage, 1.0)

    def test_score_is_withheld_below_coverage(self):
        result = weighted_score(
            {"a": 90, "b": None}, {"a": 0.60, "b": 0.40}, minimum_coverage=0.70
        )
        self.assertIsNone(result.score)
        self.assertEqual(result.missing_metrics, ("b",))

    def test_veto_overrides_scores(self):
        status = classify_watchlist(90, 90, 90, 90, "ATTRACTIVE", has_veto=True)
        self.assertEqual(status, "EXCLUDED")

    def test_expensive_qualified_company_is_monitored(self):
        status = classify_watchlist(85, 75, 80, 75, "EXPENSIVE")
        self.assertEqual(status, "MONITOR")

    def test_missing_dimension_requires_research(self):
        status = classify_watchlist(85, None, 80, 75, "FAIR")
        self.assertEqual(status, "RESEARCH")

    def test_weak_resilience_requires_review(self):
        status = classify_watchlist(85, 75, 80, 45, "ATTRACTIVE")
        self.assertEqual(status, "REVIEW")


if __name__ == "__main__":
    unittest.main()
