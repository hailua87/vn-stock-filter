import json
import unittest
from pathlib import Path


PIPELINE_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = Path(__file__).resolve().parents[2]


class VercelScaffoldTests(unittest.TestCase):
    def test_web_package_is_private_next_app(self):
        package = json.loads((REPO_ROOT / "package.json").read_text())
        self.assertTrue(package["private"])
        self.assertIn("next", package["dependencies"])
        self.assertIn("@supabase/ssr", package["dependencies"])
        self.assertIn("build", package["scripts"])

    def test_vercel_targets_singapore(self):
        config = json.loads((REPO_ROOT / "vercel.json").read_text())
        self.assertEqual(config["framework"], "nextjs")
        self.assertEqual(config["regions"], ["sin1"])

    def test_required_auth_files_exist(self):
        required = [
            "proxy.ts",
            "lib/supabase/server.ts",
            "lib/supabase/client.ts",
            "app/login/page.tsx",
            "app/auth/callback/route.ts",
            "db/supabase_rls.sql",
        ]
        for relative in required:
            self.assertTrue((REPO_ROOT / relative).is_file(), relative)

    def test_streamlit_is_not_a_production_dependency(self):
        requirements = (PIPELINE_ROOT / "requirements.txt").read_text().lower()
        self.assertNotIn("streamlit", requirements)
        self.assertFalse((REPO_ROOT / "app.py").exists())


if __name__ == "__main__":
    unittest.main()
