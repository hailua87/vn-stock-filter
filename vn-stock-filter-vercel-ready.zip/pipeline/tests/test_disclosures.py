import unittest
from pathlib import Path

from src.ingestion.disclosures import deduplicate_disclosures, normalize_disclosure_record
from src.sources.registry import load_source_registry


ROOT = Path(__file__).resolve().parents[1]


class DisclosureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = load_source_registry(ROOT / "config" / "sources.yml")

    def test_normalize_and_deduplicate(self):
        raw = {
            "source_code": "UPCOM",
            "source_url": "https://upcom.hnx.vn/files/report.pdf",
            "title": "  Annual   report  ",
            "document_type": "ANNUAL_REPORT",
            "published_at": "2026-03-31T08:00:00+07:00",
            "reporting_period_end": "2025-12-31",
            "sha256": "a" * 64,
        }
        record = normalize_disclosure_record(raw, self.registry)
        accepted, duplicates = deduplicate_disclosures([record, record])
        self.assertEqual(len(accepted), 1)
        self.assertEqual(duplicates, 1)
        self.assertEqual(record.title, "Annual report")

    def test_bad_hash_is_rejected(self):
        with self.assertRaises(ValueError):
            normalize_disclosure_record(
                {
                    "source_code": "SSC",
                    "source_url": "https://congbothongtin.ssc.gov.vn/report.pdf",
                    "title": "Disclosure",
                    "document_type": "REGULATORY_EVENT",
                    "sha256": "not-a-hash",
                },
                self.registry,
            )


if __name__ == "__main__":
    unittest.main()

