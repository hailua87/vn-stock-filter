import unittest
from pathlib import Path

from src.sources.discovery import discover_official_links
from src.sources.registry import load_source_registry, validate_official_url


ROOT = Path(__file__).resolve().parents[1]


class SourceRegistryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = load_source_registry(ROOT / "config" / "sources.yml")

    def test_registered_sources_are_disabled_until_approved(self):
        self.assertTrue(self.registry)
        self.assertTrue(all(not source.automated_enabled for source in self.registry.values()))

    def test_official_subdomain_is_allowed(self):
        url = "https://staticfile.hsx.vn/example/report.pdf"
        self.assertEqual(validate_official_url("HOSE", url, self.registry), url)

    def test_lookalike_host_is_rejected(self):
        with self.assertRaises(ValueError):
            validate_official_url("HOSE", "https://hsx.vn.example.com/report.pdf", self.registry)

    def test_non_https_is_rejected(self):
        with self.assertRaises(ValueError):
            validate_official_url("HNX", "http://hnx.vn/report.pdf", self.registry)

    def test_discovery_keeps_only_official_documents(self):
        html = """
        <a href="/files/a.pdf">Official report</a>
        <a href="https://example.com/b.pdf">External copy</a>
        <a href="/article/1">Article</a>
        """
        candidates = discover_official_links(
            html, "https://hnx.vn/disclosures", self.registry["HNX"], self.registry
        )
        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0].title, "Official report")


if __name__ == "__main__":
    unittest.main()

