from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation

from src.sources.models import SourceDefinition
from src.sources.registry import validate_official_url


TICKER_PATTERN = re.compile(r"^[A-Z0-9]{1,10}$")
EXCHANGE_ALIASES = {"HOSE": "HOSE", "HSX": "HOSE", "HNX": "HNX", "UPCOM": "UPCOM"}
STATUS_ALIASES = {
    "ACTIVE": "ACTIVE",
    "NORMAL": "ACTIVE",
    "WARNING": "WARNING",
    "CONTROL": "CONTROLLED",
    "CONTROLLED": "CONTROLLED",
    "SUSPENDED": "SUSPENDED",
    "DELISTED": "DELISTED",
}


@dataclass(frozen=True)
class NormalizedSecurity:
    ticker: str
    exchange: str
    legal_name: str
    security_type: str
    listing_status: str
    shares_outstanding: Decimal | None
    source_code: str
    source_url: str
    effective_date: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _optional_nonnegative_decimal(value: object) -> Decimal | None:
    if value in (None, ""):
        return None
    try:
        parsed = Decimal(str(value).replace(",", ""))
    except InvalidOperation as exc:
        raise ValueError("shares_outstanding must be numeric") from exc
    if parsed < 0:
        raise ValueError("shares_outstanding cannot be negative")
    return parsed


def normalize_security_record(
    raw: dict[str, object],
    registry: dict[str, SourceDefinition],
) -> NormalizedSecurity:
    source_code = str(raw.get("source_code", "")).upper()
    source_url = validate_official_url(source_code, str(raw.get("source_url", "")), registry)

    ticker = str(raw.get("ticker", "")).strip().upper()
    if not TICKER_PATTERN.fullmatch(ticker):
        raise ValueError("ticker is missing or invalid")

    exchange_raw = str(raw.get("exchange", "")).strip().upper()
    if exchange_raw not in EXCHANGE_ALIASES:
        raise ValueError(f"unsupported exchange: {exchange_raw}")
    exchange = EXCHANGE_ALIASES[exchange_raw]

    security_type = str(raw.get("security_type", "ORDINARY_SHARE")).strip().upper()
    if security_type != "ORDINARY_SHARE":
        raise ValueError("security is outside the ordinary-share universe")

    legal_name = " ".join(str(raw.get("legal_name", "")).split())
    if not legal_name:
        raise ValueError("legal_name is required")

    status_raw = str(raw.get("listing_status", "")).strip().upper()
    if status_raw not in STATUS_ALIASES:
        raise ValueError(f"unsupported listing status: {status_raw}")

    effective_date = str(raw.get("effective_date", "")).strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", effective_date):
        raise ValueError("effective_date must use YYYY-MM-DD")

    return NormalizedSecurity(
        ticker=ticker,
        exchange=exchange,
        legal_name=legal_name,
        security_type=security_type,
        listing_status=STATUS_ALIASES[status_raw],
        shares_outstanding=_optional_nonnegative_decimal(raw.get("shares_outstanding")),
        source_code=source_code,
        source_url=source_url,
        effective_date=effective_date,
    )

