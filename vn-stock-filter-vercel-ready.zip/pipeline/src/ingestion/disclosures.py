from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import datetime

from src.sources.models import SourceDefinition
from src.sources.registry import validate_official_url


SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
DOCUMENT_TYPES = {
    "FINANCIAL_STATEMENT",
    "ANNUAL_REPORT",
    "GOVERNANCE_REPORT",
    "EXTRAORDINARY_DISCLOSURE",
    "LISTING_STATUS",
    "REGULATORY_EVENT",
    "MARKET_PRICE_FILE",
    "DOCUMENT",
    "SPREADSHEET",
}


@dataclass(frozen=True)
class NormalizedDisclosure:
    source_code: str
    source_url: str
    title: str
    document_type: str
    published_at: str | None
    reporting_period_end: str | None
    sha256: str | None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _iso_datetime_or_none(value: object) -> str | None:
    if value in (None, ""):
        return None
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return parsed.isoformat()


def normalize_disclosure_record(
    raw: dict[str, object],
    registry: dict[str, SourceDefinition],
    issuer_hosts: tuple[str, ...] = (),
) -> NormalizedDisclosure:
    source_code = str(raw.get("source_code", "")).upper()
    source_url = validate_official_url(
        source_code, str(raw.get("source_url", "")), registry, issuer_hosts=issuer_hosts
    )
    title = " ".join(str(raw.get("title", "")).split())
    if not title:
        raise ValueError("title is required")

    document_type = str(raw.get("document_type", "")).upper()
    if document_type not in DOCUMENT_TYPES:
        raise ValueError(f"unsupported document type: {document_type}")

    sha256 = str(raw.get("sha256", "")).lower() or None
    if sha256 and not SHA256_PATTERN.fullmatch(sha256):
        raise ValueError("sha256 must contain exactly 64 hexadecimal characters")

    reporting_period_end = str(raw.get("reporting_period_end", "")) or None
    if reporting_period_end and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", reporting_period_end):
        raise ValueError("reporting_period_end must use YYYY-MM-DD")

    return NormalizedDisclosure(
        source_code=source_code,
        source_url=source_url,
        title=title,
        document_type=document_type,
        published_at=_iso_datetime_or_none(raw.get("published_at")),
        reporting_period_end=reporting_period_end,
        sha256=sha256,
    )


def deduplicate_disclosures(
    records: list[NormalizedDisclosure],
) -> tuple[list[NormalizedDisclosure], int]:
    accepted: list[NormalizedDisclosure] = []
    seen: set[tuple[str, str | None]] = set()
    duplicates = 0
    for record in records:
        key = (record.source_url, record.sha256)
        if key in seen:
            duplicates += 1
            continue
        seen.add(key)
        accepted.append(record)
    return accepted, duplicates

