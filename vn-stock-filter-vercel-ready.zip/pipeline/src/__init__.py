"""VN Fisher Watchlist application package."""

