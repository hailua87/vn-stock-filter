from __future__ import annotations

import os


APP_ENV = os.getenv("APP_ENV", "development")
APP_TITLE = os.getenv("APP_TITLE", "VN Fisher Watchlist")
DATABASE_URL = os.getenv("DATABASE_URL", "")
MIN_SCORE_COVERAGE = float(os.getenv("MIN_SCORE_COVERAGE", "0.70"))

