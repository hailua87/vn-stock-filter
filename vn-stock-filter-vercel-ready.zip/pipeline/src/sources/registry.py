from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

import yaml

from src.sources.models import SourceDefinition


def load_source_registry(path: Path) -> dict[str, SourceDefinition]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if payload.get("version") != 1:
        raise ValueError("Unsupported source registry version")

    registry: dict[str, SourceDefinition] = {}
    for code, raw in payload.get("sources", {}).items():
        normalized_code = str(code).upper()
        registry[normalized_code] = SourceDefinition(
            code=normalized_code,
            owner=str(raw["owner"]),
            entry_points=tuple(raw.get("entry_points", [])),
            allowed_hosts=tuple(host.lower() for host in raw.get("allowed_hosts", [])),
            supported_artifacts=tuple(raw.get("supported_artifacts", [])),
            automated_enabled=bool(raw.get("automated_enabled", False)),
            fallback_mode=str(raw.get("fallback_mode", "disabled")),
        )
    if not registry:
        raise ValueError("Source registry is empty")
    return registry


def host_is_allowed(host: str, allowed_hosts: tuple[str, ...]) -> bool:
    normalized = host.lower().rstrip(".")
    return any(normalized == allowed or normalized.endswith(f".{allowed}") for allowed in allowed_hosts)


def validate_official_url(
    source_code: str,
    url: str,
    registry: dict[str, SourceDefinition],
    issuer_hosts: tuple[str, ...] = (),
) -> str:
    code = source_code.upper()
    if code not in registry:
        raise ValueError(f"Unknown source code: {source_code}")

    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname:
        raise ValueError("Official source URL must use HTTPS and include a host")

    allowed_hosts = registry[code].allowed_hosts
    if code == "ISSUER_IR":
        allowed_hosts = tuple(host.lower() for host in issuer_hosts)
        if not allowed_hosts:
            raise ValueError("Issuer IR URL requires a company-specific allowlist")

    if not host_is_allowed(parsed.hostname, allowed_hosts):
        raise ValueError(f"Host is not approved for {code}: {parsed.hostname}")
    return url

