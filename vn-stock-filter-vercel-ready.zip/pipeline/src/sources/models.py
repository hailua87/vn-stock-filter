from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SourceDefinition:
    code: str
    owner: str
    entry_points: tuple[str, ...]
    allowed_hosts: tuple[str, ...]
    supported_artifacts: tuple[str, ...]
    automated_enabled: bool
    fallback_mode: str


@dataclass(frozen=True)
class DisclosureCandidate:
    source_code: str
    source_url: str
    title: str
    document_type: str
    published_at: str | None = None
    reporting_period_end: str | None = None
    sha256: str | None = None

