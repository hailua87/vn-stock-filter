from __future__ import annotations

from html.parser import HTMLParser
from urllib.parse import urljoin

from src.sources.models import DisclosureCandidate, SourceDefinition
from src.sources.registry import validate_official_url


DOCUMENT_SUFFIXES = {
    ".pdf": "DOCUMENT",
    ".xls": "SPREADSHEET",
    ".xlsx": "SPREADSHEET",
    ".doc": "DOCUMENT",
    ".docx": "DOCUMENT",
}


class _AnchorParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[tuple[str, str]] = []
        self._href: str | None = None
        self._text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "a":
            return
        href = dict(attrs).get("href")
        if href:
            self._href = href
            self._text = []

    def handle_data(self, data: str) -> None:
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href is not None:
            self.links.append((self._href, " ".join("".join(self._text).split())))
            self._href = None
            self._text = []


def discover_official_links(
    html: str,
    page_url: str,
    source: SourceDefinition,
    registry: dict[str, SourceDefinition],
) -> list[DisclosureCandidate]:
    """Extract allowlisted document links from supplied official HTML.

    Network retrieval is intentionally outside this function so HTML can be
    archived, hashed, and tested before link discovery.
    """
    validate_official_url(source.code, page_url, registry)
    parser = _AnchorParser()
    parser.feed(html)
    candidates: list[DisclosureCandidate] = []
    seen: set[str] = set()

    for href, anchor_text in parser.links:
        resolved = urljoin(page_url, href.strip())
        try:
            validate_official_url(source.code, resolved, registry)
        except ValueError:
            continue
        lower_path = resolved.lower().split("?", 1)[0]
        doc_type = next(
            (kind for suffix, kind in DOCUMENT_SUFFIXES.items() if lower_path.endswith(suffix)),
            None,
        )
        if not doc_type or resolved in seen:
            continue
        title = anchor_text or resolved.rsplit("/", 1)[-1]
        candidates.append(
            DisclosureCandidate(
                source_code=source.code,
                source_url=resolved,
                title=title,
                document_type=doc_type,
            )
        )
        seen.add(resolved)
    return candidates
