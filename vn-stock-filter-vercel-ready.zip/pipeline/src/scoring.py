from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class ScoreResult:
    score: float | None
    evidence_coverage: float
    missing_metrics: tuple[str, ...]


def weighted_score(
    values: Mapping[str, float | None],
    weights: Mapping[str, float],
    minimum_coverage: float = 0.70,
) -> ScoreResult:
    """Calculate a 0-100 score using only evidenced metrics.

    Missing metrics do not receive neutral values. The score is withheld when
    evidenced weight is below the configured coverage threshold.
    """
    if not 0 <= minimum_coverage <= 1:
        raise ValueError("minimum_coverage must be between 0 and 1")
    if not weights or any(weight < 0 for weight in weights.values()):
        raise ValueError("weights must be non-empty and non-negative")

    total_weight = sum(weights.values())
    if total_weight <= 0:
        raise ValueError("weights must sum to a positive value")

    evidenced_weight = 0.0
    weighted_total = 0.0
    missing: list[str] = []

    for metric, weight in weights.items():
        value = values.get(metric)
        if value is None:
            missing.append(metric)
            continue
        if not 0 <= value <= 100:
            raise ValueError(f"{metric} must be between 0 and 100")
        evidenced_weight += weight
        weighted_total += value * weight

    coverage = evidenced_weight / total_weight
    if coverage < minimum_coverage or evidenced_weight == 0:
        return ScoreResult(None, coverage, tuple(missing))

    return ScoreResult(round(weighted_total / evidenced_weight, 2), coverage, tuple(missing))


def classify_watchlist(
    quality: float | None,
    growth: float | None,
    governance: float | None,
    resilience: float | None,
    valuation_state: str | None,
    has_veto: bool = False,
) -> str:
    """Classify research status without turning the output into a trade signal."""
    if has_veto:
        return "EXCLUDED"
    if None in (quality, growth, governance, resilience):
        return "RESEARCH"
    assert quality is not None and growth is not None and governance is not None and resilience is not None
    if governance < 60 or quality < 60 or resilience < 50:
        return "REVIEW"
    if quality >= 75 and growth >= 70 and governance >= 70 and resilience >= 65:
        return "MONITOR" if valuation_state == "EXPENSIVE" else "QUALIFIED"
    return "MONITOR"
