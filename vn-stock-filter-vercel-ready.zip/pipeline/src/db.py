from __future__ import annotations

from typing import Sequence

import pandas as pd

from src.config import DATABASE_URL


SCREENER_COLUMNS = [
    "ticker",
    "exchange",
    "sector_model",
    "quality_score",
    "growth_score",
    "governance_score",
    "valuation_state",
    "evidence_coverage",
    "watchlist_status",
    "open_quality_issues",
    "as_of_date",
]


def load_screener_rows(
    exchanges: Sequence[str], sector_models: Sequence[str], statuses: Sequence[str]
) -> tuple[pd.DataFrame, str]:
    """Load governed screener rows without silently falling back to sample data."""
    if not DATABASE_URL:
        return pd.DataFrame(columns=SCREENER_COLUMNS), (
            "Database is not configured. Apply db/schema.sql and set DATABASE_URL; "
            "no synthetic scores have been generated."
        )

    try:
        from sqlalchemy import bindparam, create_engine, text

        engine = create_engine(DATABASE_URL, pool_pre_ping=True)
        query = text(
            """
            SELECT ticker, exchange, sector_model, quality_score, growth_score,
                   governance_score, valuation_state, evidence_coverage,
                   watchlist_status, open_quality_issues, as_of_date
            FROM vw_latest_screener
            WHERE exchange IN :exchanges
              AND sector_model IN :sector_models
              AND watchlist_status IN :statuses
            ORDER BY governance_score DESC NULLS LAST,
                     quality_score DESC NULLS LAST,
                     growth_score DESC NULLS LAST
            """
        ).bindparams(
            bindparam("exchanges", expanding=True),
            bindparam("sector_models", expanding=True),
            bindparam("statuses", expanding=True),
        )
        with engine.connect() as connection:
            rows = pd.read_sql(
                query,
                connection,
                params={
                    "exchanges": list(exchanges),
                    "sector_models": list(sector_models),
                    "statuses": list(statuses),
                },
            )
        return rows, ""
    except Exception as exc:  # surfaced as a governed operational message
        return pd.DataFrame(columns=SCREENER_COLUMNS), f"Database unavailable: {type(exc).__name__}."

